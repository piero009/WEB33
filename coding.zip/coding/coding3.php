<!DOCTYPE html>
<html lang="en">

<body>
    <h1>Predevine Variable</h1>
    <?php
    echo 'Selamat Datang ' . $_GET['nama'];
    ?>
</body>


</html