<!DOCTYPE html>
<html lang="en">

<body>
    <h2>Perulangan while</h2>
    <?php
    echo "Perulangan 1 sampai 10 <br />";
    $i = 1;
    while ($i <= 10) {
        echo "Perulangan ke: " . $i . '<br />';
        $i++;
    }
    ?>
</body>



</html>